synthetic test fixture 116

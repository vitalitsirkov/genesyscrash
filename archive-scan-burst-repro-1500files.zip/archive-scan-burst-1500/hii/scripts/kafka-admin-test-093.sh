kafka-admin-test-093.sh synthetic fixture, no real commands

synthetic test fixture 026

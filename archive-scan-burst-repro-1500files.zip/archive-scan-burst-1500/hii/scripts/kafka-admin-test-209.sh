kafka-admin-test-209.sh synthetic fixture, no real commands

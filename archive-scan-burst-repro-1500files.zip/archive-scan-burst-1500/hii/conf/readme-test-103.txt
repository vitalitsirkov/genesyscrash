synthetic test fixture 103

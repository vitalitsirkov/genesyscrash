kafka-admin-test-068.sh synthetic fixture, no real commands

kafka-admin-test-102.sh synthetic fixture, no real commands

kafka-admin-test-008.sh synthetic fixture, no real commands

kafka-admin-test-083.sh synthetic fixture, no real commands

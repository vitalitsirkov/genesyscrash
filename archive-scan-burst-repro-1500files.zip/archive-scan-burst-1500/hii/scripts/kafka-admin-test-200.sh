kafka-admin-test-200.sh synthetic fixture, no real commands

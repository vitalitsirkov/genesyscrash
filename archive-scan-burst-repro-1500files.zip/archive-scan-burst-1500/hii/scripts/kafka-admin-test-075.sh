kafka-admin-test-075.sh synthetic fixture, no real commands

kafka-admin-test-047.sh synthetic fixture, no real commands

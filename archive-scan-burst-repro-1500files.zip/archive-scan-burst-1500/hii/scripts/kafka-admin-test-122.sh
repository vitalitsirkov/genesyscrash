kafka-admin-test-122.sh synthetic fixture, no real commands

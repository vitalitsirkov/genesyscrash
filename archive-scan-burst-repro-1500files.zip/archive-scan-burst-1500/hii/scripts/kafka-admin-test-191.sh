kafka-admin-test-191.sh synthetic fixture, no real commands

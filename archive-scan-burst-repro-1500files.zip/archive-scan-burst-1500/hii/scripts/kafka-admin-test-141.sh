kafka-admin-test-141.sh synthetic fixture, no real commands

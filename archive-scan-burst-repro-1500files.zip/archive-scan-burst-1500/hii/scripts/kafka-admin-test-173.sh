kafka-admin-test-173.sh synthetic fixture, no real commands

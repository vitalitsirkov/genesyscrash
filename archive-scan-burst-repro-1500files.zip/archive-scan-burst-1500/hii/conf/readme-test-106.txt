synthetic test fixture 106

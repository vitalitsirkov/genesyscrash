synthetic test fixture 105

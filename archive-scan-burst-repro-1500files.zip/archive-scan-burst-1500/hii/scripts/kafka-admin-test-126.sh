kafka-admin-test-126.sh synthetic fixture, no real commands

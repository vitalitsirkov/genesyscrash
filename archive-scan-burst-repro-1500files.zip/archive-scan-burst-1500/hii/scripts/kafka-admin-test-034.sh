kafka-admin-test-034.sh synthetic fixture, no real commands

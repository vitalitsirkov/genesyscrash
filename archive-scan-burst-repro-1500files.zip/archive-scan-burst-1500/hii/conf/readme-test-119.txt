synthetic test fixture 119

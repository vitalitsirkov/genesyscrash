kafka-admin-test-160.sh synthetic fixture, no real commands

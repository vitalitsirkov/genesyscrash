kafka-admin-test-038.sh synthetic fixture, no real commands

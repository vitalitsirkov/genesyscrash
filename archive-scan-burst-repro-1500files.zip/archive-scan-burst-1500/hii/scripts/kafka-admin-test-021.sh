kafka-admin-test-021.sh synthetic fixture, no real commands

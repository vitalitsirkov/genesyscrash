synthetic test fixture 022

kafka-admin-test-199.sh synthetic fixture, no real commands

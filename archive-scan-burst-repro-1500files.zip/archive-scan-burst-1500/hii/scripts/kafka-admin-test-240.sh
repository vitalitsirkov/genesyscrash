kafka-admin-test-240.sh synthetic fixture, no real commands

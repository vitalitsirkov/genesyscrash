kafka-admin-test-189.sh synthetic fixture, no real commands

kafka-admin-test-080.sh synthetic fixture, no real commands

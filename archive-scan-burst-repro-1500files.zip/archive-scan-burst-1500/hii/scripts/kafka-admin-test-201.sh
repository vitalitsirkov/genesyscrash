kafka-admin-test-201.sh synthetic fixture, no real commands

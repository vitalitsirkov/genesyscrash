synthetic test fixture 051

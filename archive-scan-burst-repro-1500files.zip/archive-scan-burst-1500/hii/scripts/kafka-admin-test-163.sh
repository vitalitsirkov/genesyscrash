kafka-admin-test-163.sh synthetic fixture, no real commands

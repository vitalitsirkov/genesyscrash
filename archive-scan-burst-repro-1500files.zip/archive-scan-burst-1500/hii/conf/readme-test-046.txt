synthetic test fixture 046

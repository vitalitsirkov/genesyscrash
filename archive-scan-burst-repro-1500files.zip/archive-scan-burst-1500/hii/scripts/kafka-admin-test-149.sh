kafka-admin-test-149.sh synthetic fixture, no real commands

synthetic test fixture 062

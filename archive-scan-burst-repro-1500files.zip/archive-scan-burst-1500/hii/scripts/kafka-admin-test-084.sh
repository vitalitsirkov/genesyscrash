kafka-admin-test-084.sh synthetic fixture, no real commands

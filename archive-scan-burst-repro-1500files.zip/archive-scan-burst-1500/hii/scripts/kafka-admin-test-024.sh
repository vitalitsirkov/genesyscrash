kafka-admin-test-024.sh synthetic fixture, no real commands

synthetic test fixture 054

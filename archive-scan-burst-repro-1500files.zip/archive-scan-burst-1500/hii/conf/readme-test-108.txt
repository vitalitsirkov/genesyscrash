synthetic test fixture 108

synthetic test fixture 002

synthetic test fixture 042

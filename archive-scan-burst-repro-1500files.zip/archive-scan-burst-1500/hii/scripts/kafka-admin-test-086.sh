kafka-admin-test-086.sh synthetic fixture, no real commands

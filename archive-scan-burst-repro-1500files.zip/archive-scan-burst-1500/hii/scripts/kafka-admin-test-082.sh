kafka-admin-test-082.sh synthetic fixture, no real commands

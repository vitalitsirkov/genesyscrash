synthetic test fixture 113

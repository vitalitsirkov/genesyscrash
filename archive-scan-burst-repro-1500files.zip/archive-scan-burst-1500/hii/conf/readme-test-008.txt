synthetic test fixture 008

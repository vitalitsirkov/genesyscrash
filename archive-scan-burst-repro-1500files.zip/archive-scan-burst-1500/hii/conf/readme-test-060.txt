synthetic test fixture 060

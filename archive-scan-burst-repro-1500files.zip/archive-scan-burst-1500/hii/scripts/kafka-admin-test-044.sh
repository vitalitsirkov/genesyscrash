kafka-admin-test-044.sh synthetic fixture, no real commands

synthetic test fixture 063

synthetic test fixture 009

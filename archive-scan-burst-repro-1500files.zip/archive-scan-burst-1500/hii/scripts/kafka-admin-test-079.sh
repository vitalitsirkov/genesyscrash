kafka-admin-test-079.sh synthetic fixture, no real commands

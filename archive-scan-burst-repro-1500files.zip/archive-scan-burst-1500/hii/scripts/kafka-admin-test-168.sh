kafka-admin-test-168.sh synthetic fixture, no real commands

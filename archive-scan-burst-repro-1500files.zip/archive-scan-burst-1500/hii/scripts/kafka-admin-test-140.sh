kafka-admin-test-140.sh synthetic fixture, no real commands

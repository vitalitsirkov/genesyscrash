synthetic test fixture 068

kafka-admin-test-123.sh synthetic fixture, no real commands

synthetic test fixture 001

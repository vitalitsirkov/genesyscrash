kafka-admin-test-238.sh synthetic fixture, no real commands

kafka-admin-test-194.sh synthetic fixture, no real commands

kafka-admin-test-037.sh synthetic fixture, no real commands

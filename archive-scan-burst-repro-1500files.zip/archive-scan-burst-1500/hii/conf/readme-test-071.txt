synthetic test fixture 071

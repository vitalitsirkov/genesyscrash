synthetic test fixture 067

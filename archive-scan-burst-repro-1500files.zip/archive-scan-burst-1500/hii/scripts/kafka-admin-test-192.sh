kafka-admin-test-192.sh synthetic fixture, no real commands

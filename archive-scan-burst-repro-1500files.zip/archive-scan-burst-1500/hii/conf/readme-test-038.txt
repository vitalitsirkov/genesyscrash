synthetic test fixture 038

kafka-admin-test-103.sh synthetic fixture, no real commands

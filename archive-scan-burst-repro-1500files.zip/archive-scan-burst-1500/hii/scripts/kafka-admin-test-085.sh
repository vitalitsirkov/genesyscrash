kafka-admin-test-085.sh synthetic fixture, no real commands

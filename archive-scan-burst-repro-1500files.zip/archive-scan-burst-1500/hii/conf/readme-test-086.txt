synthetic test fixture 086

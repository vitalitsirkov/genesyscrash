kafka-admin-test-060.sh synthetic fixture, no real commands

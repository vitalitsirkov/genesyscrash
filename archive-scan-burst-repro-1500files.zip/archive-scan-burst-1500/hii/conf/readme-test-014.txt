synthetic test fixture 014

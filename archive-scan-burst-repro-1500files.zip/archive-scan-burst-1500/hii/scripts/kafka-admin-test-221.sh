kafka-admin-test-221.sh synthetic fixture, no real commands

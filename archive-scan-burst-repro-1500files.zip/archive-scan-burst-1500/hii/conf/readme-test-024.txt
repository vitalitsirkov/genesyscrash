synthetic test fixture 024

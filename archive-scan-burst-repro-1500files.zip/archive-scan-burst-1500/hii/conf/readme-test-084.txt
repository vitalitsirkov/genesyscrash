synthetic test fixture 084

kafka-admin-test-045.sh synthetic fixture, no real commands

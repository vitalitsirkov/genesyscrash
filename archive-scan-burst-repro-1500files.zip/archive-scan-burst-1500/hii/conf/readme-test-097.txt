synthetic test fixture 097

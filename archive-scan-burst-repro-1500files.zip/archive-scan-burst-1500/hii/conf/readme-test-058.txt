synthetic test fixture 058

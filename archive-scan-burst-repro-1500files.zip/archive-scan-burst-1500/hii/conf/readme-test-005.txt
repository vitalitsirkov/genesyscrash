synthetic test fixture 005

kafka-admin-test-232.sh synthetic fixture, no real commands

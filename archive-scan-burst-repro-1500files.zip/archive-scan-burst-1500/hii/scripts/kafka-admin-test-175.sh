kafka-admin-test-175.sh synthetic fixture, no real commands

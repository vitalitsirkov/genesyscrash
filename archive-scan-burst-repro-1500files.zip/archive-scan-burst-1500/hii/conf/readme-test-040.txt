synthetic test fixture 040

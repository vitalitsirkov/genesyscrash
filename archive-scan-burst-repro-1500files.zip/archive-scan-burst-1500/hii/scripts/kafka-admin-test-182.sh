kafka-admin-test-182.sh synthetic fixture, no real commands

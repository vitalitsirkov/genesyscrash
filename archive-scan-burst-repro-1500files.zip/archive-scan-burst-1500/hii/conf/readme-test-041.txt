synthetic test fixture 041

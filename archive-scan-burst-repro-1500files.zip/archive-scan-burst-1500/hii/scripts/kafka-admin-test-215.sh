kafka-admin-test-215.sh synthetic fixture, no real commands

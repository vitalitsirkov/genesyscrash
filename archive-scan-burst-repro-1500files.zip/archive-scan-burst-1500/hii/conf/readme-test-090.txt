synthetic test fixture 090

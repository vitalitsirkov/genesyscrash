kafka-admin-test-057.sh synthetic fixture, no real commands

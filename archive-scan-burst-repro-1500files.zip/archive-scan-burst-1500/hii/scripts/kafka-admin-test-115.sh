kafka-admin-test-115.sh synthetic fixture, no real commands

synthetic test fixture 056

synthetic test fixture 102

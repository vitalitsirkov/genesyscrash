synthetic test fixture 012

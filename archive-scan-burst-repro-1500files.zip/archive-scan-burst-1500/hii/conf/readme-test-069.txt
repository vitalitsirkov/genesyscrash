synthetic test fixture 069

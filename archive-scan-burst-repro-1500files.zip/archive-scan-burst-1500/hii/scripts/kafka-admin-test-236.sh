kafka-admin-test-236.sh synthetic fixture, no real commands

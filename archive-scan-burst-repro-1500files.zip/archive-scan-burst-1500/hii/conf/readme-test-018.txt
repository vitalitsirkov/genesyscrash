synthetic test fixture 018

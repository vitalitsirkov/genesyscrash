kafka-admin-test-196.sh synthetic fixture, no real commands

kafka-admin-test-183.sh synthetic fixture, no real commands

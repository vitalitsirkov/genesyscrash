kafka-admin-test-011.sh synthetic fixture, no real commands

kafka-admin-test-185.sh synthetic fixture, no real commands

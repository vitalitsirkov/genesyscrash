synthetic test fixture 087

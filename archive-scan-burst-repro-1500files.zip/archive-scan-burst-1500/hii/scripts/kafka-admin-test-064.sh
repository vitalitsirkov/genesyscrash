kafka-admin-test-064.sh synthetic fixture, no real commands

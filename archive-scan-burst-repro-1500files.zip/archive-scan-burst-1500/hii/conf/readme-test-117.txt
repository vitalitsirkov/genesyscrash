synthetic test fixture 117

synthetic test fixture 028

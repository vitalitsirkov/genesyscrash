synthetic test fixture 053

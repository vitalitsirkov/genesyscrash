kafka-admin-test-171.sh synthetic fixture, no real commands

kafka-admin-test-169.sh synthetic fixture, no real commands

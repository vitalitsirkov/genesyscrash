kafka-admin-test-002.sh synthetic fixture, no real commands

synthetic test fixture 088

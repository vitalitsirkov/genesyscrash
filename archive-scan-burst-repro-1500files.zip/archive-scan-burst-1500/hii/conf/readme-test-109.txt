synthetic test fixture 109

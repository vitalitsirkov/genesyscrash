kafka-admin-test-095.sh synthetic fixture, no real commands

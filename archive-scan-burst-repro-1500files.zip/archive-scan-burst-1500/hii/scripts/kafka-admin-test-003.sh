kafka-admin-test-003.sh synthetic fixture, no real commands

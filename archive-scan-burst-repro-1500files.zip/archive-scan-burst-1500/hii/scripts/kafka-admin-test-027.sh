kafka-admin-test-027.sh synthetic fixture, no real commands

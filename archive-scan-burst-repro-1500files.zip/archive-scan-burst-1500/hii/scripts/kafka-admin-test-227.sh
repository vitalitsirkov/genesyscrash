kafka-admin-test-227.sh synthetic fixture, no real commands

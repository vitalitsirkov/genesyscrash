synthetic test fixture 078

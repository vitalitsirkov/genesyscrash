kafka-admin-test-162.sh synthetic fixture, no real commands

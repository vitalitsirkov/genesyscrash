kafka-admin-test-205.sh synthetic fixture, no real commands

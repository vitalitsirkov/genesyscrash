kafka-admin-test-229.sh synthetic fixture, no real commands

synthetic test fixture 044

kafka-admin-test-129.sh synthetic fixture, no real commands

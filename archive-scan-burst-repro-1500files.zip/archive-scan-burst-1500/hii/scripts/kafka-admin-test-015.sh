kafka-admin-test-015.sh synthetic fixture, no real commands

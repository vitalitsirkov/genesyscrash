kafka-admin-test-017.sh synthetic fixture, no real commands

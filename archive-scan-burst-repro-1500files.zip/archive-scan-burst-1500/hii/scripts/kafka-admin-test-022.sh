kafka-admin-test-022.sh synthetic fixture, no real commands

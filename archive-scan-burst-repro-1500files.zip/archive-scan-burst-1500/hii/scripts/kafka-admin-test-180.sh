kafka-admin-test-180.sh synthetic fixture, no real commands

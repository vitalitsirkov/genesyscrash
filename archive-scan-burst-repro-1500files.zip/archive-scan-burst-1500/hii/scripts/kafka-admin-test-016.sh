kafka-admin-test-016.sh synthetic fixture, no real commands

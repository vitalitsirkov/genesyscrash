synthetic test fixture 101

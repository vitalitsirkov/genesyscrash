kafka-admin-test-029.sh synthetic fixture, no real commands

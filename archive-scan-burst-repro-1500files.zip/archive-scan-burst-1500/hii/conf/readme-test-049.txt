synthetic test fixture 049

kafka-admin-test-218.sh synthetic fixture, no real commands

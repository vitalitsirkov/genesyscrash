kafka-admin-test-135.sh synthetic fixture, no real commands

kafka-admin-test-112.sh synthetic fixture, no real commands

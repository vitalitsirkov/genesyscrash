synthetic test fixture 072

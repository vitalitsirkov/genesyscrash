kafka-admin-test-078.sh synthetic fixture, no real commands

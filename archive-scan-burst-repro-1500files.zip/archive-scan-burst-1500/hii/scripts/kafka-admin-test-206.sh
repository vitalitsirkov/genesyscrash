kafka-admin-test-206.sh synthetic fixture, no real commands

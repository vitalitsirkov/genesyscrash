kafka-admin-test-028.sh synthetic fixture, no real commands

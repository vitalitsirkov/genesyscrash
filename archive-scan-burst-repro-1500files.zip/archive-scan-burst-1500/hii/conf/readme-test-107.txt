synthetic test fixture 107

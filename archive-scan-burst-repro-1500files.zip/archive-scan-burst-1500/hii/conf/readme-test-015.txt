synthetic test fixture 015

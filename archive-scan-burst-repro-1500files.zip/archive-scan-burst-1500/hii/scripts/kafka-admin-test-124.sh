kafka-admin-test-124.sh synthetic fixture, no real commands

kafka-admin-test-144.sh synthetic fixture, no real commands

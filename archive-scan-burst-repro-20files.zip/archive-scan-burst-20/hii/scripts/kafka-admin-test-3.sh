kafka-admin-test-3.sh synthetic fixture, no real commands

kafka-admin-test-226.sh synthetic fixture, no real commands

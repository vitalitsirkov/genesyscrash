kafka-admin-test-239.sh synthetic fixture, no real commands

kafka-admin-test-035.sh synthetic fixture, no real commands

kafka-admin-test-204.sh synthetic fixture, no real commands

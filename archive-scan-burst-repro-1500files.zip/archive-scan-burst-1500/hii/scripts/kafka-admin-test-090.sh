kafka-admin-test-090.sh synthetic fixture, no real commands

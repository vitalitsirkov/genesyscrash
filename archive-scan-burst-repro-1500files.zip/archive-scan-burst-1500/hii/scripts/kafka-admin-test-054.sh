kafka-admin-test-054.sh synthetic fixture, no real commands

kafka-admin-test-213.sh synthetic fixture, no real commands

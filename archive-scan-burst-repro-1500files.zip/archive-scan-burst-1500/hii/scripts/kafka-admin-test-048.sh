kafka-admin-test-048.sh synthetic fixture, no real commands

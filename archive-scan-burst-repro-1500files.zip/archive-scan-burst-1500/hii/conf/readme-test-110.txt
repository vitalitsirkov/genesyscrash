synthetic test fixture 110

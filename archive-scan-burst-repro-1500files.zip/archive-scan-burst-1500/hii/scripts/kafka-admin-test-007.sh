kafka-admin-test-007.sh synthetic fixture, no real commands

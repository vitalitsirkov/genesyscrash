synthetic test fixture 098

kafka-admin-test-176.sh synthetic fixture, no real commands

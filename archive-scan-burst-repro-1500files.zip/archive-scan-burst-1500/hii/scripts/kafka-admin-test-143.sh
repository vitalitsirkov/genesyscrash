kafka-admin-test-143.sh synthetic fixture, no real commands

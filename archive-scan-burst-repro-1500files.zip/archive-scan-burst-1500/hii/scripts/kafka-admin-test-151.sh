kafka-admin-test-151.sh synthetic fixture, no real commands

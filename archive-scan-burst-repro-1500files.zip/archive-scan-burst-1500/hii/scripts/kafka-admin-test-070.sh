kafka-admin-test-070.sh synthetic fixture, no real commands

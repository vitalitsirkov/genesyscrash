kafka-admin-test-165.sh synthetic fixture, no real commands

kafka-admin-test-013.sh synthetic fixture, no real commands

kafka-admin-test-159.sh synthetic fixture, no real commands

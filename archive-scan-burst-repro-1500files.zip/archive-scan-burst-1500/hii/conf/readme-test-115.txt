synthetic test fixture 115

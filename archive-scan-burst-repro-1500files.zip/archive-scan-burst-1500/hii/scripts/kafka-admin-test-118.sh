kafka-admin-test-118.sh synthetic fixture, no real commands

synthetic test fixture 032

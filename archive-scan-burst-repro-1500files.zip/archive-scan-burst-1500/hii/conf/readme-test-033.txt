synthetic test fixture 033

synthetic test fixture 050

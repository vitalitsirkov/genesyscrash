kafka-admin-test-081.sh synthetic fixture, no real commands

kafka-admin-test-066.sh synthetic fixture, no real commands

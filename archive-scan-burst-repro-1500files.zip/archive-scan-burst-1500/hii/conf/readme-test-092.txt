synthetic test fixture 092

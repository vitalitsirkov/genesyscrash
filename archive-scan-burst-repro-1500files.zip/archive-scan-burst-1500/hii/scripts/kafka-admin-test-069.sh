kafka-admin-test-069.sh synthetic fixture, no real commands

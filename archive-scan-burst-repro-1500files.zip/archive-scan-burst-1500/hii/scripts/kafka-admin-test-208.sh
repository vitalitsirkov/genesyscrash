kafka-admin-test-208.sh synthetic fixture, no real commands

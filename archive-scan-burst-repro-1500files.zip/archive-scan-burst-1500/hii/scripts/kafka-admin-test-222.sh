kafka-admin-test-222.sh synthetic fixture, no real commands

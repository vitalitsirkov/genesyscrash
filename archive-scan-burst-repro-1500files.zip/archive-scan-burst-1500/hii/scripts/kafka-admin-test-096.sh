kafka-admin-test-096.sh synthetic fixture, no real commands

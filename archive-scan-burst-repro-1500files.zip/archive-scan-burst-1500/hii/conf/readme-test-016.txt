synthetic test fixture 016

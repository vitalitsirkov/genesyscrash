synthetic test fixture 039

kafka-admin-test-174.sh synthetic fixture, no real commands

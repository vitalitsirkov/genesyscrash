kafka-admin-test-040.sh synthetic fixture, no real commands

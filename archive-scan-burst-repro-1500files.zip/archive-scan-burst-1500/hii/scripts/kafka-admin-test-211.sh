kafka-admin-test-211.sh synthetic fixture, no real commands

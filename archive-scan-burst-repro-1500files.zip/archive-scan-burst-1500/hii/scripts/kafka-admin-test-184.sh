kafka-admin-test-184.sh synthetic fixture, no real commands

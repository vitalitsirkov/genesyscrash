kafka-admin-test-134.sh synthetic fixture, no real commands

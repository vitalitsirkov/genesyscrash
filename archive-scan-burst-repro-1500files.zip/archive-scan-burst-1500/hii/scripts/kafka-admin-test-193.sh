kafka-admin-test-193.sh synthetic fixture, no real commands

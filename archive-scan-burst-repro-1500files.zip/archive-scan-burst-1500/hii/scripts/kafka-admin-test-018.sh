kafka-admin-test-018.sh synthetic fixture, no real commands

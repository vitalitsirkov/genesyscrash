kafka-admin-test-181.sh synthetic fixture, no real commands

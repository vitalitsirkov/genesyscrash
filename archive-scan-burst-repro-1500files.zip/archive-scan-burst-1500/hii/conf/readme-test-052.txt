synthetic test fixture 052

synthetic test fixture 080

synthetic test fixture 120

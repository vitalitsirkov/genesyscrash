kafka-admin-test-202.sh synthetic fixture, no real commands

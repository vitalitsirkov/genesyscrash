kafka-admin-test-097.sh synthetic fixture, no real commands

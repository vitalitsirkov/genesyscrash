kafka-admin-test-050.sh synthetic fixture, no real commands

kafka-admin-test-031.sh synthetic fixture, no real commands

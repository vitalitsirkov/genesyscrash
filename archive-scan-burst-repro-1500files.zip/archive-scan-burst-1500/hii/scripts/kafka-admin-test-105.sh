kafka-admin-test-105.sh synthetic fixture, no real commands

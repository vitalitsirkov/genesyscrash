synthetic test fixture 025

synthetic test fixture 030

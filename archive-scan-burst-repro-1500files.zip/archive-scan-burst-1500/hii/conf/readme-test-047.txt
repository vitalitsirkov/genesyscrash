synthetic test fixture 047

kafka-admin-test-006.sh synthetic fixture, no real commands

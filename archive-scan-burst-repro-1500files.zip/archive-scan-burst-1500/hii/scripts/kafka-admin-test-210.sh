kafka-admin-test-210.sh synthetic fixture, no real commands

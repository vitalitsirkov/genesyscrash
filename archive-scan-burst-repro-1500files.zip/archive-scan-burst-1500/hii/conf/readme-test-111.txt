synthetic test fixture 111

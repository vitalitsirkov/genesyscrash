kafka-admin-test-223.sh synthetic fixture, no real commands

synthetic test fixture 104

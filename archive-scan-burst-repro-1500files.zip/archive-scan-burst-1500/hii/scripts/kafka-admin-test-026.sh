kafka-admin-test-026.sh synthetic fixture, no real commands

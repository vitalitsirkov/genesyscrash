synthetic test fixture 004

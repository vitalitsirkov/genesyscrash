synthetic test fixture 017

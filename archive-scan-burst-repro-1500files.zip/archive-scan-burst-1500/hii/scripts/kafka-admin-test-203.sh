kafka-admin-test-203.sh synthetic fixture, no real commands

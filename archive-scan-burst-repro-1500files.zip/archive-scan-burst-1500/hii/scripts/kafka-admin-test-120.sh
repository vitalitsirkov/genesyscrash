kafka-admin-test-120.sh synthetic fixture, no real commands

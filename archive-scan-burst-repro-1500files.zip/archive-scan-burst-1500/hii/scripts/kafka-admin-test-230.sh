kafka-admin-test-230.sh synthetic fixture, no real commands

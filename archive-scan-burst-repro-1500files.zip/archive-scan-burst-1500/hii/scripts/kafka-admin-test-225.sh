kafka-admin-test-225.sh synthetic fixture, no real commands

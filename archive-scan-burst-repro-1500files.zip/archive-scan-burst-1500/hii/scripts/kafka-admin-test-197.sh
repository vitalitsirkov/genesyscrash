kafka-admin-test-197.sh synthetic fixture, no real commands

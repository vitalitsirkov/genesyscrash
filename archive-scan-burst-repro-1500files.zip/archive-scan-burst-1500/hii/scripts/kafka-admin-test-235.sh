kafka-admin-test-235.sh synthetic fixture, no real commands

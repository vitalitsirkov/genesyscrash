synthetic test fixture 066

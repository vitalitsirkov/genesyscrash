kafka-admin-test-2.sh synthetic fixture, no real commands

kafka-admin-test-076.sh synthetic fixture, no real commands

kafka-admin-test-087.sh synthetic fixture, no real commands

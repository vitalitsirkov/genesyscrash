kafka-admin-test-063.sh synthetic fixture, no real commands

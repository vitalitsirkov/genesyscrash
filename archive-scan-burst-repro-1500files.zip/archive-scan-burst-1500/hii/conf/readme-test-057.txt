synthetic test fixture 057

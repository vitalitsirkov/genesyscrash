synthetic test fixture 007

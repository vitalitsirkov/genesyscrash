kafka-admin-test-071.sh synthetic fixture, no real commands

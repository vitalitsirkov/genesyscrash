kafka-admin-test-110.sh synthetic fixture, no real commands

kafka-admin-test-043.sh synthetic fixture, no real commands

kafka-admin-test-138.sh synthetic fixture, no real commands

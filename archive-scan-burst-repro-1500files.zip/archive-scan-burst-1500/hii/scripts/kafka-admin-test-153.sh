kafka-admin-test-153.sh synthetic fixture, no real commands

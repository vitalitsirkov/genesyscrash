synthetic test fixture 089

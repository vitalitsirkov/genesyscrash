kafka-admin-test-088.sh synthetic fixture, no real commands

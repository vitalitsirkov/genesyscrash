kafka-admin-test-146.sh synthetic fixture, no real commands

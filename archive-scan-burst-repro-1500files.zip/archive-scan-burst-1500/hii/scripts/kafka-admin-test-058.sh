kafka-admin-test-058.sh synthetic fixture, no real commands

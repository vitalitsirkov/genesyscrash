synthetic test fixture

kafka-admin-test-152.sh synthetic fixture, no real commands

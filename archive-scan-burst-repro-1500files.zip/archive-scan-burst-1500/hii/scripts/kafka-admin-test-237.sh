kafka-admin-test-237.sh synthetic fixture, no real commands

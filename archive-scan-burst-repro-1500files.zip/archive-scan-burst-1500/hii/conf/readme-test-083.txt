synthetic test fixture 083

kafka-admin-test-012.sh synthetic fixture, no real commands

kafka-admin-test-114.sh synthetic fixture, no real commands

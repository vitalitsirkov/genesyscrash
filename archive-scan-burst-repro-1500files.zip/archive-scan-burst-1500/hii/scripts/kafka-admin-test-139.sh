kafka-admin-test-139.sh synthetic fixture, no real commands

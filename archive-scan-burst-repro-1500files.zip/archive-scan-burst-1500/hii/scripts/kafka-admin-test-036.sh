kafka-admin-test-036.sh synthetic fixture, no real commands

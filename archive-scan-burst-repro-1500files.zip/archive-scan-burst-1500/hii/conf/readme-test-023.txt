synthetic test fixture 023

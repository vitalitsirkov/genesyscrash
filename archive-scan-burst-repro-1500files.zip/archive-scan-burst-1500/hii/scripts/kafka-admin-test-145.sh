kafka-admin-test-145.sh synthetic fixture, no real commands

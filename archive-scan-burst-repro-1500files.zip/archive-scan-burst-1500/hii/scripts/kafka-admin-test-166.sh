kafka-admin-test-166.sh synthetic fixture, no real commands

synthetic test fixture 020

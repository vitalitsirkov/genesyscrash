synthetic test fixture 075

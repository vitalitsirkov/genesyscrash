kafka-admin-test-091.sh synthetic fixture, no real commands

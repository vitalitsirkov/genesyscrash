kafka-admin-test-150.sh synthetic fixture, no real commands

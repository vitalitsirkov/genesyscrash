kafka-admin-test-224.sh synthetic fixture, no real commands

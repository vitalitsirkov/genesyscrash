synthetic test fixture 045

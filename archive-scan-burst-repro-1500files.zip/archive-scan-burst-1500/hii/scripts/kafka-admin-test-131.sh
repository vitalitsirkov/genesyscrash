kafka-admin-test-131.sh synthetic fixture, no real commands

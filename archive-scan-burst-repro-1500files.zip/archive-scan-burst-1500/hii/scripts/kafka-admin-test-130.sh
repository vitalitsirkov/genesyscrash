kafka-admin-test-130.sh synthetic fixture, no real commands

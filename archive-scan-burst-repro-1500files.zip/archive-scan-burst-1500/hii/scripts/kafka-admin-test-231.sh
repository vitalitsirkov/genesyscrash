kafka-admin-test-231.sh synthetic fixture, no real commands

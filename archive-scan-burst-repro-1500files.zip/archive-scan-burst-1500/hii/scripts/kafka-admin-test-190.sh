kafka-admin-test-190.sh synthetic fixture, no real commands

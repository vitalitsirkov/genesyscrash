kafka-admin-test-030.sh synthetic fixture, no real commands

synthetic test fixture 064

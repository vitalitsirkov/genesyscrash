kafka-admin-test-107.sh synthetic fixture, no real commands

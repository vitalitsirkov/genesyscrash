kafka-admin-test-217.sh synthetic fixture, no real commands

kafka-admin-test-148.sh synthetic fixture, no real commands

synthetic test fixture 070

kafka-admin-test-127.sh synthetic fixture, no real commands

kafka-admin-test-019.sh synthetic fixture, no real commands

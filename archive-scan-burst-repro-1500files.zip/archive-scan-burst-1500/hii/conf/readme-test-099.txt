synthetic test fixture 099

kafka-admin-test-186.sh synthetic fixture, no real commands

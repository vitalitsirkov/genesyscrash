kafka-admin-test-005.sh synthetic fixture, no real commands

kafka-admin-test-119.sh synthetic fixture, no real commands

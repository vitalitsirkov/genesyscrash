kafka-admin-test-178.sh synthetic fixture, no real commands

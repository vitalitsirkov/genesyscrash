kafka-admin-test-164.sh synthetic fixture, no real commands

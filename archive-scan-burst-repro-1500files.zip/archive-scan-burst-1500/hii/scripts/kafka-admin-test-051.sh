kafka-admin-test-051.sh synthetic fixture, no real commands

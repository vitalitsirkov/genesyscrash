synthetic test fixture 065

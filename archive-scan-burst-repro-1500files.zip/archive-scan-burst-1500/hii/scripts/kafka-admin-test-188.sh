kafka-admin-test-188.sh synthetic fixture, no real commands

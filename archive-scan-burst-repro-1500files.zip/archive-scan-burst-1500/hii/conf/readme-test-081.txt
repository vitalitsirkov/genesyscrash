synthetic test fixture 081

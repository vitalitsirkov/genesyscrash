kafka-admin-test-077.sh synthetic fixture, no real commands

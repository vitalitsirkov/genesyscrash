kafka-admin-test-109.sh synthetic fixture, no real commands

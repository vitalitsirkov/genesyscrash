kafka-admin-test-106.sh synthetic fixture, no real commands

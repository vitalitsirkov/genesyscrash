synthetic test fixture 079

kafka-admin-test-187.sh synthetic fixture, no real commands

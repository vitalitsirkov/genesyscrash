synthetic test fixture 010

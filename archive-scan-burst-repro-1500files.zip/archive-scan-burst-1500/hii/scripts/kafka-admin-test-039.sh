kafka-admin-test-039.sh synthetic fixture, no real commands

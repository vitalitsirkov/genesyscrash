synthetic test fixture 055

synthetic test fixture 112

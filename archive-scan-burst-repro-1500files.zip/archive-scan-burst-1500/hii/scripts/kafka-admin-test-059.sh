kafka-admin-test-059.sh synthetic fixture, no real commands

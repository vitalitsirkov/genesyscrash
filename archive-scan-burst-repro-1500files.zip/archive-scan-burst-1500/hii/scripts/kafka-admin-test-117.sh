kafka-admin-test-117.sh synthetic fixture, no real commands

kafka-admin-test-198.sh synthetic fixture, no real commands

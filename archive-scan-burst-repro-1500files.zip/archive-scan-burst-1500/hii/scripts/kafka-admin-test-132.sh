kafka-admin-test-132.sh synthetic fixture, no real commands

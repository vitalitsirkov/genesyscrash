synthetic test fixture 091

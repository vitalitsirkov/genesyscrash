kafka-admin-test-001.sh synthetic fixture, no real commands

synthetic test fixture 061

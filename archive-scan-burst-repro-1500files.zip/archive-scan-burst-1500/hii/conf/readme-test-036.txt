synthetic test fixture 036

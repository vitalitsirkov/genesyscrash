kafka-admin-test-154.sh synthetic fixture, no real commands

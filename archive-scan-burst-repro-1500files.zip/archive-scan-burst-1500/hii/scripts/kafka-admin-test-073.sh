kafka-admin-test-073.sh synthetic fixture, no real commands

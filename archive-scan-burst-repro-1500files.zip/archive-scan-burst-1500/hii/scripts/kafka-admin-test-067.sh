kafka-admin-test-067.sh synthetic fixture, no real commands

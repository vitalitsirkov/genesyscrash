synthetic test fixture 006

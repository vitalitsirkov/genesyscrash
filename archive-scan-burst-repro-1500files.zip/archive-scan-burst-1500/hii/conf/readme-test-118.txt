synthetic test fixture 118

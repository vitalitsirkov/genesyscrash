kafka-admin-test-065.sh synthetic fixture, no real commands

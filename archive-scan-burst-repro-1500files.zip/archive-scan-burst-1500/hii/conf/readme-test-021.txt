synthetic test fixture 021

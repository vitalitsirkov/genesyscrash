kafka-admin-test-136.sh synthetic fixture, no real commands

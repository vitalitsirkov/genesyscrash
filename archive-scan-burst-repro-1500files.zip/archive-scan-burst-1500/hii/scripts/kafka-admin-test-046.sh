kafka-admin-test-046.sh synthetic fixture, no real commands

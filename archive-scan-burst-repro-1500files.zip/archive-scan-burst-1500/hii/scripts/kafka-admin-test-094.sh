kafka-admin-test-094.sh synthetic fixture, no real commands

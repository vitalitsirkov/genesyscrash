kafka-admin-test-220.sh synthetic fixture, no real commands

synthetic test fixture 074

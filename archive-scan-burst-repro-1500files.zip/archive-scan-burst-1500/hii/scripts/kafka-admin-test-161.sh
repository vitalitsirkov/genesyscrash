kafka-admin-test-161.sh synthetic fixture, no real commands

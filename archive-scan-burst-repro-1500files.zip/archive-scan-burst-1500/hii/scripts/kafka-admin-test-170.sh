kafka-admin-test-170.sh synthetic fixture, no real commands

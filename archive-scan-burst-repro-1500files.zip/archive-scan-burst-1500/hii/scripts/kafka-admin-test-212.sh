kafka-admin-test-212.sh synthetic fixture, no real commands

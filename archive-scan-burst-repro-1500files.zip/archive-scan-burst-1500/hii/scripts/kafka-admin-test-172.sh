kafka-admin-test-172.sh synthetic fixture, no real commands

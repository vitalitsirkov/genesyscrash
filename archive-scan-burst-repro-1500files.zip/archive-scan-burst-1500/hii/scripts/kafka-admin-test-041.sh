kafka-admin-test-041.sh synthetic fixture, no real commands

kafka-admin-test-092.sh synthetic fixture, no real commands

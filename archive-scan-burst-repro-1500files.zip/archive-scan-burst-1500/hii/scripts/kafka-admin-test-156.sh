kafka-admin-test-156.sh synthetic fixture, no real commands

synthetic test fixture 027

kafka-admin-test-020.sh synthetic fixture, no real commands

synthetic test fixture 037

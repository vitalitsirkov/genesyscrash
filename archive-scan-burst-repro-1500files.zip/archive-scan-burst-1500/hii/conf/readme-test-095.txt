synthetic test fixture 095

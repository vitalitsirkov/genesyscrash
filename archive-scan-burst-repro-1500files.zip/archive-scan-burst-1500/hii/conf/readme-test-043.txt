synthetic test fixture 043

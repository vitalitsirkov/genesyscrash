kafka-admin-test-1.sh synthetic fixture, no real commands

kafka-admin-test-089.sh synthetic fixture, no real commands

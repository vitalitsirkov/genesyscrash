synthetic test fixture 013

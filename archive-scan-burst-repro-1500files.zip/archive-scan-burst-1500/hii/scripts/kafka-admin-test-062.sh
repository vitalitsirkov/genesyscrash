kafka-admin-test-062.sh synthetic fixture, no real commands

kafka-admin-test-142.sh synthetic fixture, no real commands

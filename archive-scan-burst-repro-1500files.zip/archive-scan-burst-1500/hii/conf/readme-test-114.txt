synthetic test fixture 114

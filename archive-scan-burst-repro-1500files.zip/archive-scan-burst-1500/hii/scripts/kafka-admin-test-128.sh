kafka-admin-test-128.sh synthetic fixture, no real commands

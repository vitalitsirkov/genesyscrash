kafka-admin-test-157.sh synthetic fixture, no real commands

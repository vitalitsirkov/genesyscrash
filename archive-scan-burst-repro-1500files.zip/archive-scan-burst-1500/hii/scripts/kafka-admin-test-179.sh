kafka-admin-test-179.sh synthetic fixture, no real commands

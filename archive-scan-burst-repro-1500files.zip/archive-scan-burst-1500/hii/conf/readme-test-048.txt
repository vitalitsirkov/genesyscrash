synthetic test fixture 048

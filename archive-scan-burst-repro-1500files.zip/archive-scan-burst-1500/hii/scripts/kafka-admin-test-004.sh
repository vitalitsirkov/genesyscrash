kafka-admin-test-004.sh synthetic fixture, no real commands

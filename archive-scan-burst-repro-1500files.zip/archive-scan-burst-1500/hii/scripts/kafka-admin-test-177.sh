kafka-admin-test-177.sh synthetic fixture, no real commands

kafka-admin-test-104.sh synthetic fixture, no real commands

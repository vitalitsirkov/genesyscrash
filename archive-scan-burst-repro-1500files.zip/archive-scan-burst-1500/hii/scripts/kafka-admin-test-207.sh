kafka-admin-test-207.sh synthetic fixture, no real commands

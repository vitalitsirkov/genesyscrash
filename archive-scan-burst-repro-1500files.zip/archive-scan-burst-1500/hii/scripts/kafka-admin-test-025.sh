kafka-admin-test-025.sh synthetic fixture, no real commands

synthetic test fixture 011

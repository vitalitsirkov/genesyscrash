kafka-admin-test-116.sh synthetic fixture, no real commands

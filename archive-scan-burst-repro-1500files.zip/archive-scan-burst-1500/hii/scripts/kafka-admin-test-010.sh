kafka-admin-test-010.sh synthetic fixture, no real commands

kafka-admin-test-074.sh synthetic fixture, no real commands

kafka-admin-test-053.sh synthetic fixture, no real commands

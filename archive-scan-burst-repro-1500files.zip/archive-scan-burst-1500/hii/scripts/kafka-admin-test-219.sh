kafka-admin-test-219.sh synthetic fixture, no real commands

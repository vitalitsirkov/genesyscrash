kafka-admin-test-100.sh synthetic fixture, no real commands

kafka-admin-test-023.sh synthetic fixture, no real commands

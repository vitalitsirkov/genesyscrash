kafka-admin-test-061.sh synthetic fixture, no real commands

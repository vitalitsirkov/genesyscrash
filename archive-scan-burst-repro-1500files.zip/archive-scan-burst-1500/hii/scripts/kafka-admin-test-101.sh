kafka-admin-test-101.sh synthetic fixture, no real commands

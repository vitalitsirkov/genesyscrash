kafka-admin-test-133.sh synthetic fixture, no real commands

kafka-admin-test-234.sh synthetic fixture, no real commands

kafka-admin-test-056.sh synthetic fixture, no real commands

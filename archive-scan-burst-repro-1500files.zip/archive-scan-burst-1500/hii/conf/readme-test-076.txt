synthetic test fixture 076

synthetic test fixture 073

synthetic test fixture 003

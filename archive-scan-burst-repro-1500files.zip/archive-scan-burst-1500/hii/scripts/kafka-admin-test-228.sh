kafka-admin-test-228.sh synthetic fixture, no real commands

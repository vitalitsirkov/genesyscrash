kafka-admin-test-121.sh synthetic fixture, no real commands

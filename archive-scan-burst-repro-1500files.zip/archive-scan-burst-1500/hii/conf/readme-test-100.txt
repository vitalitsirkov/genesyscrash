synthetic test fixture 100

kafka-admin-test-113.sh synthetic fixture, no real commands

kafka-admin-test-032.sh synthetic fixture, no real commands

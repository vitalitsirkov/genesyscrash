synthetic test fixture 082

kafka-admin-test-167.sh synthetic fixture, no real commands

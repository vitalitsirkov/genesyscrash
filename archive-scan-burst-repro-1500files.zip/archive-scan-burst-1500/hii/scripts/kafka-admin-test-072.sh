kafka-admin-test-072.sh synthetic fixture, no real commands

synthetic test fixture 093

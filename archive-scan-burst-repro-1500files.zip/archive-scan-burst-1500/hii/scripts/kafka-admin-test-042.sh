kafka-admin-test-042.sh synthetic fixture, no real commands

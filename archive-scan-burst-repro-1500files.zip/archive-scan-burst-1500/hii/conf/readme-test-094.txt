synthetic test fixture 094

synthetic test fixture 096

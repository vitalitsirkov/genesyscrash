kafka-admin-test-125.sh synthetic fixture, no real commands

kafka-admin-test-195.sh synthetic fixture, no real commands

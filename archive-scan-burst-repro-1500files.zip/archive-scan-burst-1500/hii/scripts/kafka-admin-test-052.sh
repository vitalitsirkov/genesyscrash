kafka-admin-test-052.sh synthetic fixture, no real commands

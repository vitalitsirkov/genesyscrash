kafka-admin-test-108.sh synthetic fixture, no real commands

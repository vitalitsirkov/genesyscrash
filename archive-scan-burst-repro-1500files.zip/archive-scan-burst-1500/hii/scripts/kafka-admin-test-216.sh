kafka-admin-test-216.sh synthetic fixture, no real commands

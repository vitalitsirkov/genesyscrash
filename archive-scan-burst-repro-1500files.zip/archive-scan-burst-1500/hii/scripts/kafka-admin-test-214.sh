kafka-admin-test-214.sh synthetic fixture, no real commands

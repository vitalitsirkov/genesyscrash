kafka-admin-test-158.sh synthetic fixture, no real commands

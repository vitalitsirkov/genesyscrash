synthetic test fixture 034

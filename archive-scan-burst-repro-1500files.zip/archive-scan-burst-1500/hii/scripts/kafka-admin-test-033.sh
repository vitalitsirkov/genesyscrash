kafka-admin-test-033.sh synthetic fixture, no real commands

kafka-admin-test-147.sh synthetic fixture, no real commands

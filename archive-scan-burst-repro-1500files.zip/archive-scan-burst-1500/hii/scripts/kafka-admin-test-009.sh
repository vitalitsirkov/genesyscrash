kafka-admin-test-009.sh synthetic fixture, no real commands

kafka-admin-test-014.sh synthetic fixture, no real commands

synthetic test fixture 059

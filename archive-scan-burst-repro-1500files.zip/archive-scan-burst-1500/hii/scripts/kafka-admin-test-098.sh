kafka-admin-test-098.sh synthetic fixture, no real commands

kafka-admin-test-111.sh synthetic fixture, no real commands

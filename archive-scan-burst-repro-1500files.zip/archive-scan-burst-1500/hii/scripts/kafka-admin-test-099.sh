kafka-admin-test-099.sh synthetic fixture, no real commands

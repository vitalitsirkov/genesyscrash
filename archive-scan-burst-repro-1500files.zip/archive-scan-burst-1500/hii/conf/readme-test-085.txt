synthetic test fixture 085

synthetic test fixture 077

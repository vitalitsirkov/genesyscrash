kafka-admin-test-155.sh synthetic fixture, no real commands

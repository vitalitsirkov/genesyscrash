kafka-admin-test-055.sh synthetic fixture, no real commands

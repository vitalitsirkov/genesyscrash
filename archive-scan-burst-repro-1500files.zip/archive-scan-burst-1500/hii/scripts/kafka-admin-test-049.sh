kafka-admin-test-049.sh synthetic fixture, no real commands

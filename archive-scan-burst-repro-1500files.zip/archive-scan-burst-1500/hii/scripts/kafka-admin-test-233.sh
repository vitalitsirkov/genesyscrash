kafka-admin-test-233.sh synthetic fixture, no real commands

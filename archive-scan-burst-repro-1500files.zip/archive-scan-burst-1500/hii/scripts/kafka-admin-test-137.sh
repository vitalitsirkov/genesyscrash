kafka-admin-test-137.sh synthetic fixture, no real commands

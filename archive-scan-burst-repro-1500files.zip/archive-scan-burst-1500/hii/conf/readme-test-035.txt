synthetic test fixture 035
